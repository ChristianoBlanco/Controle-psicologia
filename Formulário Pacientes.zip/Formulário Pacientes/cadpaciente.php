<?php

include_once("conexaocaopaciente.php");

$cpf = filter_input (INPUT_POST, 'cpf', FILTER_SANITIZE_STRING);
$nome = filter_input (INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$sobrenome = filter_input (INPUT_POST, 'sobrenome', FILTER_SANITIZE_STRING);
$nomesocial = filter_input (INPUT_POST, 'nomesocial', FILTER_SANITIZE_STRING);
$sexo = filter_input (INPUT_POST, 'sexo', FILTER_SANITIZE_STRING);
$genero = filter_input (INPUT_POST, 'genero', FILTER_SANITIZE_STRING);
$telefone = filter_input (INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
$email = filter_input (INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$endereco = filter_input (INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
$numero = filter_input (INPUT_POST, 'numero', FILTER_SANITIZE_STRING);
$complemento = filter_input (INPUT_POST, 'complemento', FILTER_SANITIZE_STRING);
$estado = filter_input (INPUT_POST, 'estado', FILTER_SANITIZE_STRING);
$cidade = filter_input (INPUT_POST, 'cidade', FILTER_SANITIZE_STRING);
$pais = filter_input (INPUT_POST, 'pais', FILTER_SANITIZE_STRING);
$nomecontato1 = filter_input (INPUT_POST, 'nomecontato1', FILTER_SANITIZE_STRING);
$telcontato1 = filter_input (INPUT_POST, 'telcontato1', FILTER_SANITIZE_STRING);
$nomecontato2 = filter_input (INPUT_POST, 'nomecontato2', FILTER_SANITIZE_STRING);
$telcontato2 = filter_input (INPUT_POST, 'telcontato2', FILTER_SANITIZE_STRING);
$observacao = filter_input (INPUT_POST, 'observacao', FILTER_SANITIZE_STRING);

$result_cadpacientes ="INSERT INTO cadpacientes (cpf, nome, sobrenome, nomesocial, sexo, genero, telefone, email, endereco, numero, complemento,estado, cidade, pais, nomecontato1, telcontato1, nomecontato2, telcontato2, observacao)
VALUES ('$cpf', '$nome', '$sobrenome', '$nomesocial', '$sexo', '$genero', '$telefone', '$email', '$endereco', '$numero', '$complemento', '$estado', '$cidade','$pais', '$nomecontato1', '$telcontato1', '$nomecontato2', '$telcontato2', '$observacao')";
	
$resultado_conexaopacientes = mysqli_query ($conexaopacientes, $result_cadpacientes);
if (mysqli_insert_id($conexaopacientes)) {
	header("Location: form_pacientes.php");
	}