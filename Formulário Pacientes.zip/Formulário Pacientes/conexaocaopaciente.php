<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "calendario";

$conexaopacientes = mysqli_connect ($servidor , $usuario, $senha ,$dbname);

